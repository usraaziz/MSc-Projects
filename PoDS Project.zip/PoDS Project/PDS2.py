#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Dec  2 14:55:36 2023

@author: usraaziz
"""

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt 
from gensim.parsing.preprocessing import remove_stopwords
from wordcloud import WordCloud 

df = pd.read_csv(r'/Users/usraaziz/Desktop/spotify_songs.csv')
df. head (10) 
df.describe
df. shape, df.columns, df.info()
columns_to_drop = ['track_album_id','playlist_id','track_id']
dfen = df[df["language"] == 'en']
# Creating a column with only english songs
dfen = dfen.drop(columns=columns_to_drop)
# dropping columns to create world clouds
# Convert the 'track_album_release_date' column to datetime with format
dfen['track_album_release_date'] = pd.to_datetime(dfen['track_album_release_date'], format='%Y-%m-%d', errors='coerce')
# Extract the year and create a new column
dfen['Year'] = dfen['track_album_release_date'].dt.year

#* Explanatory data analysis

# Bar chart of count of songs vs languages 
import matplotlib.pyplot as plt 
fig,ax = plt.subplots (figsize=(20,10))
import seaborn as sns
ax= sns.countplot(x='language', data=df)
dfen.isnull().sum()
# There are no null values in the english songs 

# Unigram wordcloud of lyrcis 
from gensim.parsing.preprocessing import remove_stopwords

from nltk.corpus import stopwords
stop_words = (stopwords. words ('english'))
dfen_str = remove_stopwords(str(dfen))
all_lyrics_str = ' '.join(dfen['lyrics'].astype(str))
plt.figure(figsize=(20,20))
wordcloud = WordCloud(width = 3000, height = 2000).generate(all_lyrics_str)
plt.imshow(wordcloud)
# 

# lyrics
import nltk
from nltk.corpus import stopwords
stop_words = (stopwords.words('english')) 
from nltk.tokenize import word_tokenize
word_tokens  = word_tokenize(all_lyrics_str)
print(all_lyrics_str[1:200])
print(word_tokens[1:40]) # captures punctuation also and key token words

# Bigram of lyrics **TRY AGAIN**
from nltk.tokenize import sent_tokenize
lyrics_sentences = sent_tokenize(all_lyrics_str)
from nltk import bigrams
bi_grams = list(bigrams(lyrics_sentences))

# Assuming dfen is your DataFrame and 'lyrics' is the column containing lyrics
dfen_str = remove_stopwords(str(dfen))
all_lyrics_str = ' '.join(dfen['lyrics'].astype(str))

# Tokenize the text into bigrams
tokenized_bigrams = list(bigrams(all_lyrics_str.split()))

# Combine bigrams into a single string
bigrams_str = ' '.join([' '.join(bigram) for bigram in tokenized_bigrams])

# Create a WordCloud with bigrams
wordcloud = WordCloud(width=800, height=400, background_color='white').generate(bigrams_str)

# Display the WordCloud using matplotlib
plt.figure(figsize=(10, 5))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis('off')
plt.show()

# Correlation heatmap
selected_columns = ['track_popularity', 'danceability', 'energy', 'key', 'loudness', 'mode', 'speechiness', 'acousticness', 'instrumentalness', 'valence', 'tempo', 'duration_ms']
song_features = dfen[selected_columns]
plt.figure(figsize=(20,20))
sns.heatmap(song_features.corr(), annot=True)

# lyrics over time 
from sklearn.feature_extraction.text import CountVectorizer
# Tokenize and count word frequencies for each year
vectorizer = CountVectorizer(stop_words='english')
word_counts = vectorizer.fit_transform(dfen['lyrics'])
word_counts_dfen = pd.DataFrame(word_counts.toarray(), columns=vectorizer.get_feature_names_out())
word_counts_dfen['Year'] = dfen['Year']

# Group by year and sum the word frequencies
word_counts_by_year = word_counts_dfen.groupby('Year').sum()

# Plot the most frequent words for each year
top_words = 10  # specify the number of top words to display
for year in word_counts_by_year.index:
    top_words_year = word_counts_by_year.loc[year].nlargest(top_words)
    top_words_year.plot(kind='bar', title=f'Most Frequent Words in {year}', xlabel='Words', ylabel='Frequency')
    plt.show()
    
# top 10 lyrics over each decade subplot 
# Extract the decade from the release date (you may need to adapt this based on your actual data)
dfen['Decade'] = (dfen['Year'] // 10) * 10

# Tokenize and count word frequencies for each decade
vectorizer = CountVectorizer(stop_words='english')
word_counts = vectorizer.fit_transform(dfen['lyrics'])
word_counts_dfen = pd.DataFrame(word_counts.toarray(), columns=vectorizer.get_feature_names_out())
word_counts_dfen['Decade'] = dfen['Decade']

# Group by decade and sum the word frequencies
word_counts_by_decade = word_counts_dfen.groupby('Decade').sum()

# Plot the most frequent words for each decade in subplots
top_words = 10  # specify the number of top words to display

# Create subplots
fig, axs = plt.subplots(nrows=len(word_counts_by_decade.index), figsize=(10, 5 * len(word_counts_by_decade.index)))

# Plot for each decade
for i, decade in enumerate(word_counts_by_decade.index):
    top_words_decade = word_counts_by_decade.loc[decade].nlargest(top_words)
    top_words_decade.plot(kind='bar', ax=axs[i], title=f'Most Frequent Words in {decade}s', xlabel='Words', ylabel='Frequency')

# Adjust layout
plt.tight_layout()
plt.show()

# unigram word cloud 
dfen.to_csv('/Users/usraaziz/Desktop/spotfiy_song_eng.csv', sep=',', index=False, encoding='utf-8')
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import CountVectorizer

# bigram word cloud
from nltk.tokenize import sent_tokenize
from nltk import bigrams
from wordcloud import WordCloud
import matplotlib.pyplot as plt

# Sample text
all_lyrics_str = ' '.join(dfen['lyrics'].astype(str))

# Tokenize into sentences
lyrics_sentences = sent_tokenize(all_lyrics_str)

# Generate bigrams from sentences
bi_grams = list(bigrams(lyrics_sentences))

# Combine bigrams into a single string
bigrams_str = ' '.join([' '.join(bigram) for bigram in bi_grams])

# Create a WordCloud with bigrams
wordcloud = WordCloud(width=800, height=400, background_color='white').generate(bigrams_str)

# Display the WordCloud using matplotlib
plt.figure(figsize=(10, 5))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis('off')
plt.show()

# Sentiment score each year (negative/neutral/positive)
import pandas as pd
from nltk.sentiment.vader import SentimentIntensityAnalyzer

# Perform sentiment analysis using VADER
sid = SentimentIntensityAnalyzer()
dfen['Sentiment'] = dfen['lyrics'].apply(lambda x: sid.polarity_scores(x)['compound'])

# Group by year and calculate average proportions
average_sentiment_proportions = dfen.groupby(['Year', 'Sentiment_Category']).size().unstack(fill_value=0)
average_sentiment_proportions = average_sentiment_proportions.div(average_sentiment_proportions.sum(axis=1), axis=0)

# Create a scatter plot
colors = {'Positive': 'green', 'Neutral': 'orange', 'Negative': 'red'}
plt.figure(figsize=(10, 5))
for sentiment_category, color in colors.items():
    plt.scatter(average_sentiment_proportions.index, average_sentiment_proportions[sentiment_category], c=color, label=sentiment_category, s=100)

plt.title('Average Sentiment Proportions Over Years')
plt.xlabel('Year')
plt.ylabel('Average Sentiment Score')
plt.legend(title='Sentiment Category')
plt.show()

# scatterplot matrix of song features
import seaborn as sns

# Scatterplot matrix
# Pairplot using Seaborn
sns.pairplot(dfen)
plt.suptitle('Pairplot of Song Features', y=1.02)
plt.show()

# Boxplot of song features every decade option 1
for song_feature in song_features:
    plt.figure(figsize=(10, 6))
    sns.boxplot(x='Decade', y=song_feature, data=dfen)
    plt.title(f'Boxplot Distribution of {song_feature} Every Decade')
    plt.xlabel('Decade')
    plt.ylabel(song_feature)
    plt.show()
    
# violin boxplot  of song features every decade option 2
for song_feature in song_features:
    plt.figure(figsize=(10, 6))
    sns.violinplot(x='Decade', y=song_feature, data=dfen, palette='muted')
    plt.title(f'Violin Boxplot of {song_feature} Every Decade')
    plt.xlabel('Decade')
    plt.ylabel(song_feature)
    plt.show()

# Create histograms for each song feature
song_features.hist(figsize = (15,15))
plt.show()