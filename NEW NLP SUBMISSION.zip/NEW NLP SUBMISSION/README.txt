PyTorch version: 2.2.1+cu121
Pandas version: 2.0.3
NumPy version: 1.25.2
Seaborn version: 0.13.1
Transformers version: 4.40.1
NLTK version: 3.8.1
Keras version: 3.3.2
Scikit-learn version: 1.4.2
Joblib version: 1.2.0
Datasets version: 2.19.1
TensorFlow version: 2.15.0

For Testing_SVM-2 file you need the following files to run this:
- lemmas_as_strings5.pkl
- lemmas_as_strings6.pkl
- oversample_train.pkl
- y_test_over.pkl
- y2_predict_svm2

For BERT_Testing2 file you need the following to run this:
- oversample_trainNEW.pkl

Testing set for BERT model: test_set_for_final_model.pkl

Training dataset: train_E6oV3lV.csv

Test dataset: test_tweets_anuFYb8.csv

For Copy_of_BERT_MODEL_TRIN_2.ipynb and Copy_of_NLP_CW.ipynb the following files is needed:
- train_E6oV3lV.csv
- test_tweets_anuFYb8.csv

Google Colab link for BERT training: https://colab.research.google.com/drive/1-GXFaucDkJ5LcyhFN24NanXuzJDS1GOh?usp=sharing 
Google Colab link for simple machine learning models training: https://colab.research.google.com/drive/1ua4U5XSS77yNvMxcy-wMN2__BAgb2aWO?usp=sharing 
Google Colab link for testing BERT model: https://colab.research.google.com/drive/1l6-yIwH-IDSwFcn1ojuUKTxgtPTC1AaD?usp=sharing
Google Colab link for training XLNet + testing:  https://colab.research.google.com/drive/1W4zuxodWYH_GPKWFMVwleySV7HW888iX?usp=sharing

Video link: https://cityuni-my.sharepoint.com/:v:/r/personal/usra_aziz_city_ac_uk/Documents/Recordings/ML%20video-20240507_220349-Meeting%20Recording.mp4?csf=1&web=1&e=fW3l1d&nav=eyJyZWZlcnJhbEluZm8iOnsicmVmZXJyYWxBcHAiOiJTdHJlYW1XZWJBcHAiLCJyZWZlcnJhbFZpZXciOiJTaGFyZURpYWxvZy1MaW5rIiwicmVmZXJyYWxBcHBQbGF0Zm9ybSI6IldlYiIsInJlZmVycmFsTW9kZSI6InZpZXcifX0%3D