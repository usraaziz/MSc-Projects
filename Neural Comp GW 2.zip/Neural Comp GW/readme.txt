*****************
FOR PYTHON CODE 
*****************

inital_preprocessing.ipynb contains train test split, encoding & class balancing requires original_data.csv. 

python_model.ipynb contains model training and performance metrics on training and testing data requires train_data.csv & test_data.csv 

python_model.ipynb can be run directly without the need to run inital_preprocessing.ipynb as train and test csv files are already generated.


*****************
FOR MATLAB CODE 
*****************

Neural_CompMAIN contains basic statistics and data visualisation of the original dataset requires HR_comma_sep 2.csv. Please run this first

Neural_Comp contains model training and performance metrics on training and testing data requires Neural_CompMAIN to run first

Neural_Comp_MATLAB.pdf is the pdf version of Neural_Comp

Neural_CompMAIN.pdf is the pdf version of Neural_CompMAIN.mlx

Note HR_comma_sep 2.csv and original_data.csv contain the same dataset.

