
# A Comparison of Decision Tree (DT) and Random Forest (RF) Applied to Pima Indians diabetes dataset

 

## Inside the zip file:
- In the main file, there is explanatory analysis and pre-processing techniques done to the dataset and the baseline models of DT and RF and the performance of these models was calculated using performance metrics, ROC curve and confusion matrices.
- In the RF training model file, first, we split the data into training and testing sets. Secondly, undersampling was done as there is a target class imbalance. Thirdly, we train the RF model using the undersampled data with two hyperparameters, the number of trees and the number of predictors. Lastly, The optimal RF model was then found.
- In the RF testing model file, we evaluated the optimal RF model using the test set and then calculated the model's performance using the confusion matrix, performance metrics and ROC curves. 
- In the DT training model file, first, we split the data into training and testing sets. Secondly, undersampling was done as there is a target class imbalance. Thirdly, we train the DT model using the undersampled data with one hyperparameter, minimum leaf size. Lastly, the optimal DT model was then found.
-  In the DT testing model file, we evaluated the optimal DT model using the test set and then calculated the model's performance using the confusion matrix, performance metrics and ROC curves. 
- In the important features, the important features for both models were calculated. This could be used to enhance both training models. 
## Instructions
The order to run the files is below:

1. Diabetes_original_MAIN.mlx
2. Feature_Importance.mlx
3. RF_Training.mlx
4. RF_Testing.mlx
5. DT_Training.mlx
6. DT_Testing.mlx

The video showcasing my poster and my code is linked here: https://cityuni-my.sharepoint.com/:v:/g/personal/usra_aziz_city_ac_uk/EbhVJcRyJi9LoKsKKHYiRyQBpgHzey8BqxWmopNDuO7Igw?e=XqEy2y&nav=eyJyZWZlcnJhbEluZm8iOnsicmVmZXJyYWxBcHAiOiJTdHJlYW1XZWJBcHAiLCJyZWZlcnJhbFZpZXciOiJTaGFyZURpYWxvZy1MaW5rIiwicmVmZXJyYWxBcHBQbGF0Zm9ybSI6IldlYiIsInJlZmVycmFsTW9kZSI6InZpZXcifX0%3D 
