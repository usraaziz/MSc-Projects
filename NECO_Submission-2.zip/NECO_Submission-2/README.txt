
# A Comparative Study on the Heart Disease Dataset through Multilayer Perceptrons and Support Vector Machines  

## Set up instructions:
1. Extract all the files from the zip file
2. Change directory (cd) to the extracted folder, and save any test data into this root folder
3. Create a new virtualenv and install packages from requirements.txt:
 virtualenv cw_env_Usra_Aziz  
 cd cw_env_Usra_Aziz  
 source bin/activate  
 cd -  
 pip install -r requirements.txt

4. Copy and paste the following code to open the IPYNB in the following order:
 jupyter notebook Heart_Disease_MAIN.ipynb 
 'MLP_optimised.joblib'
 'SVM_optimised.joblib' 
 jupyter notebook MLP_testing.ipynb  
 jupyter notebook SVM_testing.ipynb

5.  'MLP_optimised.joblib' and 'SVM_optimised.joblib' is necessary for jupyter notebook MLP_testing.ipynb  and jupyter notebook SVM_testing.ipynb. Upload to environment
## Inside the zip file
- In the main file, there is explanatory analysis and pre-processing techniques done to the dataset and the data is split into training and testing sets.
- In the MLP training model file, we train the MLP model using the standardized data with 3 hyperparameters, learning rate, mometum and hidden layer size. Also, the training performance metrics, ROC curve of class 1 (has heart disease) and confusion matrix was calculated and plotted. Lastly, the optimal MLP model was then found. 
- In the MLP testing model file, we evaluated the optimal MLP model using the test set and then calculated the model's performance using the confusion matrix, performance metrics and ROC curve of class 1. 
- In the SVM training model file, we train the SVM model using the standardized data with 3 hyperparameters, lthe regularisation parameter C, kernel function and degree of polynomial. Also, the training performance metrics, ROC curve of class 1 (has heart disease) and confusion matrix was calculated and plotted. Lastly, the optimal SVM model was then found. 
-  In the SVM testing model file, we evaluated the optimal SVM model using the test set and then calculated the model's performance using the confusion matrix, performance metrics and ROC curve of class 1. 
- MLP_optimised.joblib: The optimised MLP model
- SVM_optimised.joblib: The optimised SVM model
- x_test.csv: input testing data
- y_test.csv: labeled testing data

## requirements
joblib==0.16.0
matplotlib==3.2.2
numpy==1.18.5
pandas==1.0.5
scikit-learn==0.23.1
scipy==1.5.0
seaborn==0.10.1
skorch==0.9.0
torch==1.7.1

Video link: https://cityuni-my.sharepoint.com/:v:/g/personal/usra_aziz_city_ac_uk/ER1QCxzn8L1Nv08Rj03ZI-EB2aS1ztLr-rdmm4Dyd7aoLg?e=1LvSQN&nav=eyJyZWZlcnJhbEluZm8iOnsicmVmZXJyYWxBcHAiOiJTdHJlYW1XZWJBcHAiLCJyZWZlcnJhbFZpZXciOiJTaGFyZURpYWxvZy1MaW5rIiwicmVmZXJyYWxBcHBQbGF0Zm9ybSI6IldlYiIsInJlZmVycmFsTW9kZSI6InZpZXcifX0%3D 
